
%this was only for the purpose of testing my crossover function and to test
%function linking...
function [c1,c2]= gene()
    popsize= 15;
    chrome=ones([1,popsize],0);
    for x=1:popsize
    for n=1:3
        gene=[randi(10, [1,2]),randi(2,[1,1])];
        chrome=[chrome,gene];
    end
    end
    finchrom= (reshape(chrome,[9,popsize]))'
    C= mat2cell(finchrom,ones([1 popsize]));
    r1= randi(popsize, [1 1]);
    r2= randi(popsize, [1 1]);
    c1=C{r1}
    c2=C{r2}
end
