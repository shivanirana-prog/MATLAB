function [ x,y ] = cal( a,b )
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
x=a-b;
y=a+b

end

