chrom=ones([1,5],0);
for x=1:5
for n=1:3
x=[randi(10, [1,2]),randi(2,[1,1])];
chrom=[chrom,x]
end
end
finchrom=(reshape(chrom,[9,5]))'
for i=1:5
gen1=finchrom(i,:)
%y=fitnessfunction(gen1,rl,rb,windows and door positions)
%gen1=[genn1,y] that is we concatenate the total fitness of chromosome at
%the end of it
end
%cross=the matrix of gen1 chromosomes which will be given for crossover
