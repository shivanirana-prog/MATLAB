
%here i have taken input as arrays from the gene function.. because i don't
%have the fitness function yet. 
function [] = crossover
    [c1,c2]= gene();
    child1= [c1(1:3),c2(4:6),c1(7:9)]
    child2= [c2(1:3),c1(4:6),c2(7:9)]
end    