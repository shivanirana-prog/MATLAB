A = 0; B = 10; C=0:1;
i=10;
randomArray = (A-1) + (B-(A-1))*randperm(9);
intarray = floor(randomArray) + 1

a=