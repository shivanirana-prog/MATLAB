Numjobs = 3;
NumTask = 3
chromosome = repmat(1:NumTask,Numjobs,3);
order = randperm(NumTask*Numjobs);
chromosome = chromosome(order)
