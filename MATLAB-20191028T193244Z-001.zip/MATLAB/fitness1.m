function fitvalue = fitness1(arr)
fitvalue=0;
rx =10;
ry =10;
bb=5;
lb=6;
% when f is bed
bx=arr(1);
by=arr(2);
o=arr(3);

if(o==1) %horizontal
    if((bx+bb)<rx)
        fitvalue=fitvalue+10;
        fprintf('breadth of bed within room limits. fitness=%i',fitvalue);
    end
    if((by+lb)<ry)
        fitvalue=fitvalue+10 ;
        fprintf('length of bed within room limits. fitness=%i',fitvalue);
    end
end
end