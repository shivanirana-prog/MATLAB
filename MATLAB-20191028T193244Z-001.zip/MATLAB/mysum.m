tic
a=10;
b=4;
c=a+b;
d=a-b;
toc

